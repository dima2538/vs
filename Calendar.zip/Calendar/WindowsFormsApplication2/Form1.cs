﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToLongTimeString();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                monthCalendar1.Enabled = true;
                monthCalendar1.Visible = true;
                dateTimePicker1.Enabled = true;
                dateTimePicker1.Visible = true;
            }else
            {
                monthCalendar1.Enabled = false;
                monthCalendar1.Visible = false;
                dateTimePicker1.Enabled = false;
                dateTimePicker1.Visible = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox2.Checked)
            {
                label1.Enabled = true;
                label1.Visible = true;
            }
            else
            {
                label1.Enabled = false;
                label1.Visible = false;

            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                groupBox2.Enabled = true;
                groupBox2.Visible = true;
            }
            else
            {
                groupBox2.Enabled = false;
                groupBox2.Visible = false;

            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                groupBox3.Enabled = true;
                groupBox3.Visible = true;
            }
            else
            {
                groupBox3.Enabled = false;
                groupBox3.Visible = false;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int dd,mm,yy;          

            dd = int.Parse(textBox1.Text);
            mm = int.Parse(textBox2.Text);
            yy = int.Parse(textBox3.Text);
            DateTime bd = new DateTime(yy, mm, dd);
            


            DateTime tod = DateTime.Today;

            TimeSpan date = tod - bd;

            int days = Math.Abs(date.Days);
            MessageBox.Show("Від дня народження пройшло "+ days + " днів");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer2.Start();
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        int MaxLength = 18, operation = 0;
        public Form1()
        {
            InitializeComponent();
        }
        void _0()
        {
            if (label1.Text != "0") if (label1.Text.Length < MaxLength) label1.Text += "0";
        }
        void _1()
        {
            if(label1.Text=="0")
            label1.Text = "1";
            else if(label1.Text.Length< MaxLength) label1.Text += "1";
        }
        void _2()
        {
            if (label1.Text == "0")
                label1.Text = "2";
            else if (label1.Text.Length < MaxLength) label1.Text += "2";
        }
        void _3()
        {
            if (label1.Text == "0")
                label1.Text = "3";
            else if (label1.Text.Length < MaxLength) label1.Text += "3";
        }
        void _4()
        {
            if (label1.Text == "0")
                label1.Text = "4";
            else if (label1.Text.Length < MaxLength) label1.Text += "4";
        }
        void _5()
        {
            if (label1.Text == "0")
                label1.Text = "5";
            else if (label1.Text.Length < MaxLength) label1.Text += "5";
        }
        void _6()
        {
            if (label1.Text == "0")
                label1.Text = "6";
            else if (label1.Text.Length < MaxLength) label1.Text += "6";
        }
        void _7()
        {
            if (label1.Text == "0")
                label1.Text = "7";
            else if (label1.Text.Length < MaxLength) label1.Text += "7";
        }
        void _8()
        {
            if (label1.Text == "0")
                label1.Text = "8";
            else if (label1.Text.Length < MaxLength) label1.Text += "8";
        }
        void _9()
        {
            if (label1.Text == "0")
                label1.Text = "9";
            else if (label1.Text.Length < MaxLength) label1.Text += "9";
        }
        void Oper()
        {
            switch (operation)
            {
                case 1:
                    {
                        label1.Text = (double.Parse(label2.Text.Remove(label2.Text.Length-1,1))+double.Parse(label1.Text)).ToString();
                        label2.Text="";
                        operation = 0;
                        break;
                    }
                case 2:
                    {
                        label1.Text = (double.Parse(label2.Text.Remove(label2.Text.Length - 1, 1)) - double.Parse(label1.Text)).ToString();
                        label2.Text = "";
                        operation = 0;
                        break;
                    }
                case 3:
                    {
                        label1.Text = (double.Parse(label2.Text.Remove(label2.Text.Length - 1, 1)) * double.Parse(label1.Text)).ToString();
                        label2.Text = "";
                        operation = 0;
                        break;
                    }
                case 4:
                    {
                        label1.Text = (double.Parse(label2.Text.Remove(label2.Text.Length - 1, 1)) / double.Parse(label1.Text)).ToString();
                        label2.Text = "";
                        operation = 0;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }
        void _p()
        {
            if (operation == 0)
            {
                label2.Text = label1.Text + "+";
                label1.Text = "0";
                operation = 1;
            }
            else
            {
                Oper();
                label2.Text = label1.Text + "+";
                label1.Text = "0";
                operation = 1;
                
            }
        }
        void _m()
        {
            if (operation == 0)
            {
                label2.Text = label1.Text + "-";
                label1.Text = "0";
                operation = 2;
            }
            else
            {
                Oper();
                label2.Text = label1.Text + "-";
                label1.Text = "0";
                operation = 2;

            }
        }
        void _mp()
        {
            if (operation == 0)
            {
                label2.Text = label1.Text + "*";
                label1.Text = "0";
                operation = 3;
            }
            else
            {
                Oper();
                label2.Text = label1.Text + "*";
                label1.Text = "0";
                operation = 3;

            }
        }
        void _d()
        {
            if (operation == 0)
            {
                label2.Text = label1.Text + "/";
                label1.Text = "0";
                operation = 4;
            }
            else
            {
                Oper();
                label2.Text = label1.Text + "/";
                label1.Text = "0";
                operation = 4;

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            _1();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            _2();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            _0();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = "0";
            label2.Text = "";
            operation = 0;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            _3();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            _4();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            _5();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            _6();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            _7();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            _8();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            _9();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            _m();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Oper();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            _mp();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            _d();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (label1.Text[0] == '-') label1.Text = label1.Text.Remove(0, 1);
            else label1.Text = "-" + label1.Text;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (label1.Text.IndexOf('.') == -1)
                label1.Text += ".";
        }

        private void button23_Click(object sender, EventArgs e)
        {
            label1.Text = (double.Parse(label1.Text) / 100).ToString();
        }

        private void button22_Click(object sender, EventArgs e)
        {
            label1.Text = (1/double.Parse(label1.Text)).ToString();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            label1.Text = (Math.Sqrt(double.Parse(label1.Text))).ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (label1.Text.Length > 1)
                label1.Text = label1.Text.Remove(label1.Text.Length - 1, 1);
            else label1.Text = "0";
        }

        private void button24_Click(object sender, EventArgs e)
        {
            label1.Text=(Math.Sin(double.Parse(label1.Text))).ToString();
        }

        private void button25_Click(object sender, EventArgs e)
        {
            label1.Text = (Math.Cos(double.Parse(label1.Text))).ToString();
        }

        private void button26_Click(object sender, EventArgs e)
        {
            label1.Text = (Math.Tan(double.Parse(label1.Text))).ToString();
        }

        private void button27_Click(object sender, EventArgs e)
        {
            label1.Text = (1/Math.Tan(double.Parse(label1.Text))).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "0";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            _p();
        }
    }
}
